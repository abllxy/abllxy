// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DDObject/DDUserWidget.h"
#include "TKMenuWidget.generated.h"

/**
 * 
 */
UCLASS()
class DATADRIVENFRAMEWORK_API UTKMenuWidget : public UDDUserWidget
{
	GENERATED_BODY()
	
	
	
	
};
