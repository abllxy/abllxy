// Fill out your copyright notice in the Description page of Project Settings.

#include "TKGameInstance.h"




void UTKGameInstance::GIInfo(FString Info)
{
	DDHelper::Debug(Info, 5.f);
}
