// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "DDAIController.generated.h"

/**
 * 
 */
UCLASS()
class DATADRIVEN_API ADDAIController : public AAIController
{
	GENERATED_BODY()
	
	
	
	
};
